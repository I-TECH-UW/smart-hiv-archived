This page includes a depiction of end-users and related stakeholders as introduced in the WHO Digital Adaptation Kit for HIV(link forthcoming).

The specific roles and demographic profile of the personas will vary depending on the setting, the generic personas are based on the WHO core competencies and credentials of different health worker personas.


### Targeted generic personas

The targeted personas for the HIV Digital Adaptation Kit are
health professionals operating in care settings that are able to provide
the required essential interventions for HIV delivery. Their
key competences of are defined in the following table.

**Descriptions of key generic personas**

<!-- {% include fragment-actors.liquid %} -->

<br/>